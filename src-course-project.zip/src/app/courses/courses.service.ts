export class CourseService {
  private courses = [
    {
      id: 1,
      name: 'Java',
      status: 'online'
    },
    {
      id: 2,
      name: 'Angular',
      status: 'Inperson'
    },
    {
      id: 3,
      name: 'Python',
      status: 'InPerson'
    }
  ];

  getCoureses() {
    return this.courses;
  }

  getCourse(id: number) {
    console.log(id);
    const course = this.courses.find(
      (s) => {
        return s.id === id;
      }
    );
    return course;
  }

  updateCourse(id: number, courseInfo: {name: string, status: string}) {
    console.log('Update course service');
   const course = this.courses.find(
      (s) => {
        return s.id === id;
      }
    );
  
    if (course) {
      course.name = courseInfo.name;
      course.status = courseInfo.status;
    }
  }
}
