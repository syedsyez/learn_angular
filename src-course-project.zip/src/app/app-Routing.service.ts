import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { CourseComponent } from "./courses/course/course.component";
import { CoursesComponent } from "./courses/courses.component";
import { EditCourseComponent } from "./courses/edit-course/edit-course.component";
import { HomeComponent } from "./home/home.component";
import { NotFoundComponent } from "./not-found/not-found.component";
import { DeactivateComponentGuard } from "./shared/deactivate-Guard.service";
import { EditUserComponent } from "./users/edit-user/edit-user.component";
import { UserComponent } from "./users/user/user.component";
import { UsersComponent } from "./users/users.component";

const appRoutes:Routes=[

    {path:'',component:HomeComponent },
    {path:'courses',component:CoursesComponent,children:[
      {path:':id',component:CourseComponent},
      {path:':id/edit',
      canDeactivate:[DeactivateComponentGuard],
      component:EditCourseComponent}
     
    ]},
    {path:'users',component:UsersComponent, 
    children:[
      {path:'new',component:EditUserComponent},
      {path:':id',component:UserComponent},
      {path:':id/edit',component:EditUserComponent}
      
    ]},
    {path:'**',component:NotFoundComponent}
   
  ];
  

@NgModule({
    imports:[RouterModule.forRoot(appRoutes)],
    exports:[RouterModule]

})
export class AppRoutingModule{

}