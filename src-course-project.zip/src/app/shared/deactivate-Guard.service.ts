import {ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot, UrlTree} from '@angular/router';
import { Observable } from 'rxjs';
import { EditCourseComponent } from '../courses/edit-course/edit-course.component';

export interface ComponentDeactivate{
    canNagivate()//:Observable<boolean>|Promise<boolean>|boolean
}

export class DeactivateComponentGuard implements
 CanDeactivate<ComponentDeactivate>{
    
    canDeactivate(component: ComponentDeactivate, 
        currentRoute: ActivatedRouteSnapshot,
         currentState: RouterStateSnapshot,
          nextState?: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
     return component.canNagivate();
    }

}