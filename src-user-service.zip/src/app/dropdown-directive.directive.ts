import { Directive, ElementRef, HostBinding, HostListener, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appDropdownDirective]',
  //exportAs:'appDropdownDirective'

})
export class DropdownDirectiveDirective {

  @HostBinding('class.open') 
  isShow=false;

  constructor(private elementRef:ElementRef,private render:Renderer2) { }

  
  @HostListener('document:click',['$event'])
  openDropdown(event:Event){
    console.log('event registered');

    this.isShow = this.elementRef.nativeElement.
    contains(event.target)?!this.isShow:false;
  }
  

}
