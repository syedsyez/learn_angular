export class CourseService {
  private courses = [
    {
      id: 0,
      name: 'Java',
      status: 'online'
    },
    {
      id: 1,
      name: 'Angular',
      status: 'Inperson'
    },
    {
      id: 2,
      name: 'Python',
      status: 'InPerson'
    }
  ];

  getCoureses() {
    return this.courses;
  }

  getCourse(id: number) {
    console.log(id);
    const course = this.courses.find(
      (s) => {
        return s.id === id;
      }
    );
    
    console.log(course);
    return course;
  }

  updateCourse(id: number, courseInfo: {name: string, status: string}) {
    const course = this.courses.find(
      (s) => {
        return s.id === id;
      }
    );
    if (course) {
      course.name = courseInfo.name;
      course.status = courseInfo.status;
    }
  }
}
