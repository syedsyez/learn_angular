import { Component } from '@angular/core';
import { AccountServices } from './account.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[AccountServices]
  
})
export class AppComponent {
  title = 'acctManagement';
  constructor(private accountService:AccountServices){}
  accounts= this.accountService.getAccounts();

  onCreateAccount(account:{accountName:string,status:string}){
    this.accountService.addAccount(account);

  }

}
