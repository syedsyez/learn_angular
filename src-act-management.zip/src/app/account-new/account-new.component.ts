import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-new',
  templateUrl: './account-new.component.html',
  styleUrls: ['./account-new.component.css']
})
export class AccountNewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  onSubmit(accountName:string,accountStatus:string){
    
  }

}
