import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-display',
  templateUrl: './acct-display.component.html',
  styleUrls: ['./acct-display.component.css']
})
export class AcctDisplayComponent implements OnInit {

  @Input()
  account!:{accountName:string,status:string};
  @Input()
  id!:number;
  constructor() { }

  ngOnInit(): void {
  }

}
