import { Component, OnInit,EventEmitter,Input,Output } from '@angular/core';
import { LoggingService } from 'src/logging-service';
import { UserDataService } from '../user-data.service';

@Component({
  selector: 'app-user-active',
  templateUrl: './user-active.component.html',
  styleUrls: ['./user-active.component.css'],
  
})
export class UserActiveComponent implements OnInit {

  constructor(private logService:LoggingService,
    private userDataService:UserDataService) { }
   @Output()
   userActiveEmitter=new EventEmitter<number>();
   @Input()
   activeUsers:string[]=[];


  ngOnInit(): void {
  }

  setToInactive(index:number){
   this.userDataService.setUserToInActive(index);
    //this.userActiveEmitter.emit(index);
    this.logService.logMessages('status is set to Inactive');

  }

}
