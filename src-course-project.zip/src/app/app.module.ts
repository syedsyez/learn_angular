import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule} from '@angular/router'


import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { UsersComponent } from './users/users.component';
import { CoursesComponent} from './courses/courses.component'
import { UserComponent } from './users/user/user.component';
import { EditCourseComponent } from './courses/edit-course/edit-course.component';
import { CourseComponent } from './courses/course/course.component';
import { CourseService } from './courses/courses.service';
import { Routes } from '@angular/router';

const appRoutes:Routes=[
  {path:'',component:HomeComponent },
  {path:'courses',component:CoursesComponent,children:[
    {path:':id',component:CourseComponent},
    {path:':id/edit',component:EditCourseComponent}
  ]},
  {path:'users',component:UsersComponent, 
  children:[
    {path:':id/:name',component:UserComponent}
  ]},
 
];


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    UsersComponent,
    CoursesComponent,
    UserComponent,
    EditCourseComponent,
    CourseComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [CourseService],
  bootstrap: [AppComponent]
})
export class AppModule { }
