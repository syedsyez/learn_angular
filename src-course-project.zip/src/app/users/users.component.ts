import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserManageService } from './user-manage.service';
import { User } from './user-model';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent {
  constructor(private userService:UserManageService,
    private router:Router,
    private route:ActivatedRoute){

  }
  users:User[] = this.userService.getUsers();

  onAddUser(){
    this.router.navigate(['new'],{relativeTo:this.route});
  }

}
