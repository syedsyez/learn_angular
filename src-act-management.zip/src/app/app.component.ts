import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'acctManagement';
  accounts:{accountName:string,status:string}[]=[
    {accountName:'Test Account',status:'active'},
    {accountName:'Master account',status:'Inactive'},
    {accountName:'NRI account',status:'new'}
  ];

}
