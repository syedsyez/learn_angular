import { 
  Component, 
  OnInit,
  EventEmitter,
  Input, Output
 } from '@angular/core';
import { UserDataService } from '../user-data.service';

@Component({
  selector: 'app-user-inactive',
  templateUrl: './user-inactive.component.html',
  styleUrls: ['./user-inactive.component.css']
})
export class UserInactiveComponent implements OnInit {

  constructor(private userDataService:UserDataService) { }
  @Input()
  inactiveUsers:string[]=[];
  @Output()
  inactiveUserEmitter = new EventEmitter<number>();

  ngOnInit(): void {
  }
  setToActive(index:number){
    this.inactiveUserEmitter.emit(index);
    
  }


}
