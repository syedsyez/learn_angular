import { Component, OnInit } from '@angular/core';

import { CourseService } from '../courses.service';

@Component({
  selector: 'app-edit-course',
  templateUrl: './edit-course.component.html',
  styleUrls: ['./edit-course.component.css']
})
export class EditCourseComponent implements OnInit {
  course: {id: number, name: string, status: string};
  courseName = '';
  courseStatus = '';

  constructor(private courseService: CourseService) { }

  ngOnInit() {
    this.course = this.courseService.getCourse(1);
    if(this.course){

    this.courseName = this.course.name;
    this.courseStatus = this.course.status;
  }
  }

  onUpdateCourse() {
    this.courseService.updateCourse(this.course.id, {name: this.course.name, status: this.courseStatus});
  }

}
