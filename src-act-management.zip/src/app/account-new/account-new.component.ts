import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { AccountServices } from '../account.service';

@Component({
  selector: 'app-account-new',
  templateUrl: './account-new.component.html',
  styleUrls: ['./account-new.component.css'],
  
  
})
export class AccountNewComponent implements OnInit {

  constructor(private accountService:AccountServices) { }
  @Output()
  createAccount 
  = new EventEmitter<{accountName:string,status:string}>();

  ngOnInit(): void {
  }

  onSubmit(name:string,accountStatus:string){
  // this.createAccount.emit({accountName:name,status:accountStatus});
   this.accountService
   .addAccount({accountName:name,status:accountStatus});
  }

}
