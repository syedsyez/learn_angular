import { User } from "./user-model";

export class UserManageService{
   private users:User[] = [
        {
          id: 1,
          name: 'Max'
        },
        {
          id: 2,
          name: 'Anna'
        },
        {
          id: 3,
          name: 'Chris'
        }
      ];

      getUsers(){
        return  this.users;
      }

      updateUser(id:number,user:User){
        let index :number;
        const existinUser =this.users.find((s,i)=>{
            if(s.id === id){
                index = i;
            }
        })
        if(existinUser){
            user.id = id;
            this.users[index] = user;
        }else{
            this.users.push(user)
        }
      
       
      }

      getUser(id:number){
        return this.users.find((s)=>{
            return s.id === id;
        });
      }
}