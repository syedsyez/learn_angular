import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ComponentDeactivate } from 'src/app/shared/deactivate-Guard.service';

import { CourseService } from '../courses.service';

@Component({
  selector: 'app-edit-course',
  templateUrl: './edit-course.component.html',
  styleUrls: ['./edit-course.component.css']
})
export class EditCourseComponent implements OnInit, AfterViewInit, ComponentDeactivate {
  course: {id: number, name: string, status: string};
  @ViewChild('f')
  editCourseForm :NgForm;
  cname = '';
  courseStatus = '';
  isEditable =false;
  id: number;

  constructor(private route:ActivatedRoute,private courseService: CourseService) { }
 
  ngAfterViewInit(): void {
 
  }

  ngOnInit() {
     this.id = +this.route.snapshot.params['id']; 
    this.course = this.courseService.getCourse(this.id);
    this.route.queryParams.subscribe(param =>{
     this.isEditable =  param['isEditable'] ==='1'?true:false;
    }

    );

     this.cname = this.course.name;
    this.courseStatus = this.course.status;

 

  
  
  }

  onUpdateCourse() {
    console.log(this.editCourseForm);
    console.log('update course is invoked');
    this.courseService.updateCourse(this.course.id, 
      {
        name: this.editCourseForm.form.get('courseName').value, 
        status: this.editCourseForm.form.get('status').value  
    }
      );
  }

  canNagivate() {
   if(this.cname !== this.course.name || 
    this.courseStatus !== this.course.status){
      return confirm('Do you want to leave this page');
    }
    return true;

  }

  OnReset(){
   this.editCourseForm.reset();
  }

  retrieveValues(){
    this.editCourseForm.setValue({
      "courseName": "Python",
      "courseContent": "asdfasdfsf\nasdfasdf\nasdfasdf\nasdfasdf\n",
      "courseDuration": 1,
      "status": "online"
    
  });
  }


}
