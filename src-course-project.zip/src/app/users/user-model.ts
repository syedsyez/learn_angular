export interface User{
    id:number;
    name:string;
    email?:string;
    phoneNumber?:string;
    city?:string;
    coursesRegistered?:string[];
}