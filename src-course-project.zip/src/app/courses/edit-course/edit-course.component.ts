import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ComponentDeactivate } from 'src/app/shared/deactivate-Guard.service';

import { CourseService } from '../courses.service';

@Component({
  selector: 'app-edit-course',
  templateUrl: './edit-course.component.html',
  styleUrls: ['./edit-course.component.css']
})
export class EditCourseComponent implements OnInit,ComponentDeactivate {
  course: {id: number, name: string, status: string};
  @ViewChild('f')
  editCourseForm :NgForm;
  cname = '';
  courseStatus = '';
  isEditable =false;

  constructor(private route:ActivatedRoute,private courseService: CourseService) { }

  ngOnInit() {
    const id = +this.route.snapshot.params['id']; 
    this.course = this.courseService.getCourse(id);
    this.route.queryParams.subscribe(param =>{
     this.isEditable =  param['isEditable'] ==='1'?true:false;
    }

    );

     this.cname = this.course.name;
    this.courseStatus = this.course.status;
  
  }

  onUpdateCourse() {
    console.log(this.editCourseForm);
    console.log('update course is invoked');
   // this.courseService.updateCourse(this.course.id, 
   //   {name: this.courseName, status: this.courseStatus});
  }

  canNagivate() {
   if(this.cname !== this.course.name || 
    this.courseStatus !== this.course.status){
      return confirm('Do you want to leave this page');
    }
    return true;

  }


}
