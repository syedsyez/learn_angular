import { Component, OnInit } from '@angular/core';
import { CourseService } from '../courses.service';
import {ActivatedRoute, Router} from '@angular/router';



@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {
  course: {id: number, name: string, status: string};

  constructor(private router:Router, private route:ActivatedRoute,private courseService: CourseService) { }

  ngOnInit() {
    this.route.params.subscribe(param=>{
      let id = +param['id'];
      this.course = this.courseService.getCourse(id);
    });
    
  }
  OnEditCourse(){ 
    this.router.navigate(['edit'],{relativeTo:this.route,
      queryParamsHandling:'preserve'});
  }

}
