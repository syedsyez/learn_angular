import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { CourseService } from 'src/app/courses/courses.service';
import { UserDataStorageService } from 'src/app/shared/userstorage.service';
import { UserManageService } from '../user-manage.service';
import { User } from '../user-model';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

  userForm:FormGroup;
  id:number;
  user:User;
  courses: {id: number, name: string, status: string}[] =[];

  constructor(private userService:UserManageService,
    private route:ActivatedRoute,
    private courseService:CourseService,
    private userDataService:UserDataStorageService) { }

  ngOnInit(): void {
    this.id = +this.route.snapshot.params['id'];
    this.user = this.userService.getUser(this.id);
    this.courses = this.courseService.getCoureses()

    this.userForm = new FormGroup({
      name: new FormControl(this.user.name,[Validators.required]),
      email: new FormControl(null,[Validators.required,
        Validators.email]),
      phoneNumber:new FormControl(null),
      city:new FormControl(null),
      coursesRegistered:new FormControl(null)
    });

 

  }

  OnSubmit(){
    this.user =this.userForm.value;
    this.user.id = this.id;
    this.userDataService.saveUserData(this.user);
    //this.userService.updateUser(this.id,this.userForm.value);
  }

}
