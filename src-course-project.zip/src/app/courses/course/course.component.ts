import { Component, OnInit } from '@angular/core';
import { CourseService } from '../courses.service';
import {ActivatedRoute} from '@angular/router';



@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {
  course!: {id: number, name: string, status: string};

  constructor(private route:ActivatedRoute,private courseService: CourseService) { }

  ngOnInit() {
    let id = +this.route.snapshot.params['id'];

    this.route.params.subscribe(param=>{
      id = +param['id'];
      this.course = this.courseService.getCourse(id);
    });
    
  }

}
