import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { CourseService } from 'src/app/courses/courses.service';
import { UserDataStorageService } from 'src/app/shared/userstorage.service';
import { UserManageService } from '../user-manage.service';
import { User } from '../user-model';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

  userForm:FormGroup;
  id:number;
  user:User;
  editMode=false;
  courses: {id: number, name: string, status: string}[] =[];
   userName:string='';

  constructor(private userService:UserManageService,
    private route:ActivatedRoute,
    private courseService:CourseService,
    private userDataService:UserDataStorageService) { }
  

  ngOnInit(): void {
    this.id = +this.route.snapshot.params['id'];
    if(this.id){
      this.editMode = true;
       this.user = this.userService.getUser(this.id);
       this.userName = this.user.name;
    }
    this.courses = this.courseService.getCoureses();
    this.initForm();
    }

   private initForm(){
    this.userForm = new FormGroup({
      name: new FormControl(this.userName,[Validators.required]),
      email: new FormControl(null,[Validators.required,
        Validators.email]),
      phoneNumber:new FormControl(null),
      city:new FormControl(null),
      coursesRegistered:new FormControl(null)
    });
   }

  OnSubmit(){
    this.user =this.userForm.value;
    if(this.editMode){
      this.id = this.userService.getUsers().length+1;
     }
    this.user.id = this.id;
    console.log()
    this.userDataService.saveUserData(this.user);
    //this.userService.updateUser(this.id,this.userForm.value);
  }

}
