import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { User } from "../users/user-model";

@Injectable()
export class UserDataStorageService{

    constructor(private http:HttpClient){}

    saveUserData(user:User){
        this.http.put('https://tech-academy-2f30a-default-rtdb.firebaseio.com/users.json',user).subscribe(response=>{
            console.log("**user data service invoked");
            console.log(response);
        })
    }

}