import { Component, OnInit } from '@angular/core';
import { CourseService } from '../courses.service';



@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {
  course: {id: number, name: string, status: string};

  constructor(private courseService: CourseService) { }

  ngOnInit() {
    this.course = this.courseService.getCourse(1);
  }

}
