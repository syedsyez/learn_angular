export class LoggingService{
    logMessages(message:string){
        console.log(message);
    }
}