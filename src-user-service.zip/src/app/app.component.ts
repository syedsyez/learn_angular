import { Component,OnInit } from '@angular/core';
import { LoggingService } from 'src/logging-service';
import { UserDataService } from './user-data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[LoggingService,UserDataService]
  
})
export class AppComponent implements OnInit{
  title = 'usermanagement';
  constructor(private logService:LoggingService,
    private userDataService:UserDataService){}
    
  activeUsers:string[]=[];
  inactiveUsers:string[]=[];
  
    ngOnInit(): void {
  
      this.activeUsers=this.userDataService
      .getActiveUsers();
      this.inactiveUsers=this.userDataService
      .getInActiveUsers();
  }
 

}
