import { Component, OnInit,OnDestroy } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import {Subscription} from 'rxjs';
import { ComponentDeactivate } from 'src/app/shared/deactivate-Guard.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit,OnDestroy,ComponentDeactivate {
  user!: {id: number, name: string};
  paramSubscription:Subscription;

  constructor(private router:Router, private route:ActivatedRoute) { }
 

  ngOnInit() {
  /*this.user = {
    id:this.route.snapshot.params['id'],
    name:this.route.snapshot.params['name']
  }*/
  
  this.paramSubscription = this.route.params
  .subscribe(param=>{
    this.user ={
    id: param['id'],  
    name: param['name']
    }
  });

  }

  ngOnDestroy(): void {
   this.paramSubscription.unsubscribe();
  }

  onEditUser(){
    this.router.navigate(['edit'],{relativeTo:this.route});
  }

  
  canNagivate() {
   console.log('in user componenet');
  }
 

}
