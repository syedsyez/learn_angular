import { Component, OnDestroy, OnInit} from '@angular/core';
import { Router} from '@angular/router';
import { interval, Observable, Subscription } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit,OnDestroy {

  mysubscription:Subscription;

  constructor(private router:Router) { }


  ngOnInit() {
 const customSubscription = new Observable(observe=>{
     let count =0;
      setInterval(()=>{
        observe.next(count);
        count++;
        if(count===10){
          observe.error('Error occured in subscription');
        }
      },1000);

    });

    this.mysubscription = customSubscription.subscribe({
      next:data=>{
      console.log(data);
    },
   error: error=>{
      console.log('Error handled for subscription');
    }});
  }

  onLoadCourses(){
    this.router.navigate(['courses']);

  }

  ngOnDestroy(): void {
    this.mysubscription.unsubscribe();
  }

}
