import { Component } from '@angular/core';
import { UserManageService } from './user-manage.service';
import { User } from './user-model';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent {
  constructor(private userService:UserManageService){

  }
  users:User[] = this.userService.getUsers();

}
