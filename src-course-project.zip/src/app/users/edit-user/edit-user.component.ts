import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { UserManageService } from '../user-manage.service';
import { User } from '../user-model';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

  userForm:FormGroup;
  id:number;
  user:User;

  constructor(private userService:UserManageService,
    private route:ActivatedRoute) { }

  ngOnInit(): void {
    this.id = +this.route.snapshot.params['id'];
    this.user = this.userService.getUser(this.id);

    this.userForm = new FormGroup({
      name: new FormControl(this.user.name,[Validators.required]),
      email: new FormControl(null,[Validators.required,
        Validators.email]),
      phoneNumber:new FormControl(null),
      city:new FormControl(null)
    });

 

  }

  OnSubmit(){
    this.userService.updateUser(this.id,this.userForm.value);
  }

}
