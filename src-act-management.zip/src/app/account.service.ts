export class AccountServices{
    private accounts:{accountName:string,status:string}[]=[
        {accountName:'Test Account',status:'active'},
        {accountName:'Master account',status:'Inactive'},
        {accountName:'NRI account',status:'new'}
      ];

      getAccounts(){
        return this.accounts;
      }
      addAccount(account:{accountName:string,status:string}){
        this.accounts.push(account);
      }
      updateAccountStatus(index:number,newStatus:string){
        this.accounts[0].status =newStatus;
      }
}