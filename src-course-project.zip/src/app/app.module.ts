import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { UsersComponent } from './users/users.component';
import { CoursesComponent} from './courses/courses.component'
import { UserComponent } from './users/user/user.component';
import { EditCourseComponent } from './courses/edit-course/edit-course.component';
import { CourseComponent } from './courses/course/course.component';
import { CourseService } from './courses/courses.service';

import { NotFoundComponent } from './not-found/not-found.component';
import { DeactivateComponentGuard } from './shared/deactivate-Guard.service';
import { AppRoutingModule } from './app-Routing.service';
import { EditUserComponent } from './users/edit-user/edit-user.component';
import { AddUserComponent } from './users/add-user/add-user.component';
import { UserManageService } from './users/user-manage.service';



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    UsersComponent,
    CoursesComponent,
    UserComponent,
    EditCourseComponent,
    CourseComponent,
    NotFoundComponent,
    EditUserComponent,
    AddUserComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    ReactiveFormsModule
    
  ],
  providers: [CourseService,DeactivateComponentGuard,UserManageService],
  bootstrap: [AppComponent]
})
export class AppModule { }
