import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AcctDisplayComponent } from './acct-display/acct-display.component';
import { AccountNewComponent } from './account-new/account-new.component';

@NgModule({
  declarations: [
    AppComponent,
    AcctDisplayComponent,
    AccountNewComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
