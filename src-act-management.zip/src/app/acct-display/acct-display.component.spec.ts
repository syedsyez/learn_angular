import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AcctDisplayComponent } from './acct-display.component';

describe('AcctDisplayComponent', () => {
  let component: AcctDisplayComponent;
  let fixture: ComponentFixture<AcctDisplayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AcctDisplayComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AcctDisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
