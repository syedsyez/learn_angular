import { LoggingService } from "src/logging-service";
import {Injectable} from "@angular/core";

@Injectable()
export class UserDataService{

    constructor(private logService:LoggingService){}

    private activeUsers:string[]=[
        'Alex',
        'Max',
        'Brook'
      ];
     private inactiveUsers:string[]=[
        'Allen',
        'Wilson',
        'John'
      ];
      private accounts:{name:string,status:string}[]=[];
    
      setUserToInActive(index:number){
   
        this.accounts.push()
        let user = this.activeUsers[index];
        this.activeUsers.splice(index,1);
        this.inactiveUsers.push(user);
        this.logService.logMessages('status is set to Inactive');
    
      }
      setUserToActive(index:number){
        let user = this.inactiveUsers[index];
        this.inactiveUsers.splice(index,1);
        this.activeUsers.push(user);
        this.logService.logMessages('status is set to Inactive');
    
      }
      getActiveUsers(){
        return this.activeUsers;
      }

      getInActiveUsers(){
        return this.inactiveUsers;
      }

}