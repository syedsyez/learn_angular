import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DropdownDirectiveDirective } from './dropdown-directive.directive';
import { UserActiveComponent } from './user-active/user-active.component';
import { UserInactiveComponent } from './user-inactive/user-inactive.component';

@NgModule({
  declarations: [
    AppComponent,
    UserActiveComponent,
    UserInactiveComponent,
    DropdownDirectiveDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
