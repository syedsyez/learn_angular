import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

  userForm:FormGroup;

  constructor() { }

  ngOnInit(): void {
    this.userForm = new FormGroup({
      userName: new FormControl(null,[Validators.required]),
      email: new FormControl(null,[Validators.required,
        Validators.email])
    });

  }

}
