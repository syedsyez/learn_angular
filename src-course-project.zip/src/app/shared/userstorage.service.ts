import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { UserManageService } from "../users/user-manage.service";
import { User } from "../users/user-model";

@Injectable()
export class UserDataStorageService{

    constructor(private http:HttpClient, private userService:UserManageService){}

    saveUserData(user:User){
       /* this.http.post('https://tech-academy-2f30a-default-rtdb.firebaseio.com/users.json',user)
        .subscribe(response=>{
            console.log("**user data service invoked");
            console.log(response);
          
        })*/
        this.userService.updateUser(user.id,user);
    }

}